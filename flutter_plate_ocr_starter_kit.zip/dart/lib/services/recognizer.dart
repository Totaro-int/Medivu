// lib/services/recognizer.dart
import 'dart:typed_data';
import 'package:tflite_flutter/tflite_flutter.dart' as tfl;

class Recognizer {
  final tfl.Interpreter _interpreter;
  final int inputW, inputH;

  Recognizer._(this._interpreter, this.inputW, this.inputH);

  static Future<Recognizer> create(String asset, {int inputW=160, int inputH=48}) async {
    final options = tfl.InterpreterOptions();
    try { options.addDelegate(tfl.NnApiDelegate()); } catch (_) {}
    final interpreter = await tfl.Interpreter.fromAsset(asset, options: options);
    return Recognizer._(interpreter, inputW, inputH);
  }

  String infer(Uint8List cropRgb) {
    // TODO: preprocess to (1,H,W,3) float/int8 as expected, run inference
    // TODO: greedy/beam search CTC decode or model-embedded decoder
    return "";
  }

  void close() => _interpreter.close();
}

// lib/utils/postprocess.dart
String postprocessKoreanPlate(String raw) {
  String s = raw.toUpperCase()
      .replaceAll('O','0').replaceAll('I','1').replaceAll('B','8').replaceAll('S','5');
  final patterns = [
    RegExp(r'\b\d{2,3}[가-힣]\d{4}\b'),
    RegExp(r'\b\d{2}[가-힣]\d{4}\b'),
  ];
  for (final p in patterns) {
    final m = p.firstMatch(s);
    if (m != null) return m.group(0)!;
  }
  return s;
}

// lib/services/detector.dart
import 'dart:typed_data';
import 'package:tflite_flutter/tflite_flutter.dart' as tfl;

class Detection {
  final RectF box;
  final double score;
  Detection(this.box, this.score);
}

class RectF {
  final double x, y, w, h;
  RectF(this.x, this.y, this.w, this.h);
}

class Detector {
  final tfl.Interpreter _interpreter;
  final int inputW, inputH;

  Detector._(this._interpreter, this.inputW, this.inputH);

  static Future<Detector> create(String asset, {int inputW=640, int inputH=640}) async {
    final options = tfl.InterpreterOptions();
    try { options.addDelegate(tfl.NnApiDelegate()); } catch (_) {}
    final interpreter = await tfl.Interpreter.fromAsset(asset, options: options);
    return Detector._(interpreter, inputW, inputH);
  }

  List<Detection> infer(Uint8List rgbBytes, int width, int height) {
    // TODO: resize/letterbox rgbBytes -> input tensor
    // TODO: run inference and decode (NMS) to detections
    return <Detection>[];
  }

  void close() => _interpreter.close();
}

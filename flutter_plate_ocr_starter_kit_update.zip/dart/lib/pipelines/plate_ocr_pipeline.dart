// lib/pipelines/plate_ocr_pipeline.dart
import 'dart:isolate';
import 'dart:typed_data';
import '../services/detector.dart';
import '../services/recognizer.dart';
import '../services/tracker.dart';
import '../utils/postprocess.dart';

class PlateOcrRequest {
  final Uint8List rgbBytes;
  final int width;
  final int height;
  final int rotation;
  PlateOcrRequest({required this.rgbBytes, required this.width, required this.height, required this.rotation});
}

class PlateOcrResult {
  final RectF box;
  final String text;
  PlateOcrResult(this.box, this.text);
}

Future<void> runPlateOcrIsolate(SendPort initPort) async {
  final det = await Detector.create('assets/models/plate_yolo_int8.tflite');
  final rec = await Recognizer.create('assets/models/ocr_crnn_int8.tflite');
  final tracker = IouTracker(iouThresh: 0.5, maxAge: 10);
  final port = ReceivePort();
  initPort.send(port.sendPort);

  await for (final msg in port) {
    final PlateOcrRequest r = msg as PlateOcrRequest;
    final dets = det.infer(r.rgbBytes, r.width, r.height);
    // Convert Detection -> [x,y,w,h,score]
    final detBoxes = dets.map((d)=> [d.box.x, d.box.y, d.box.w, d.box.h, d.score]).toList();
    final tracks = tracker.update(detBoxes);
    if (tracks.isEmpty) continue;
    final t = tracks.first; // pick best (you can rank by size/score/stability)
    // TODO: crop plate region from r.rgbBytes using t.box, then call rec.infer()
    final text = postprocessKoreanPlate("");
    initPort.send(PlateOcrResult(RectF(t.box[0], t.box[1], t.box[2], t.box[3]), text));
  }
}

"""
Regression evaluation for pre/post conversion accuracy:
- Detection: mAP (stub; integrate pycocotools if needed)
- OCR: CER/WER with example inference for ONNXRuntime and TFLite

Usage examples:
  # ONNX (OCR)
  python regression_eval.py --ocr-gt ocr_val.json --ocr-model recognizer.onnx --ocr-kind onnx --charlist charset.txt --input-size 48,160

  # TFLite (OCR, int8/fp16/fp32)
  python regression_eval.py --ocr-gt ocr_val.json --ocr-model recognizer.tflite --ocr-kind tflite --charlist charset.txt --input-size 48,160
"""
import argparse, json, numpy as np
from pathlib import Path

def cer(ref, hyp):
    """Character Error Rate via Levenshtein distance / len(ref)."""
    R, H = len(ref), len(hyp)
    dp = np.zeros((R+1, H+1), dtype=int)
    for i in range(R+1): dp[i,0]=i
    for j in range(H+1): dp[0,j]=j
    for i in range(1,R+1):
        for j in range(1,H+1):
            cost = 0 if ref[i-1]==hyp[j-1] else 1
            dp[i,j] = min(dp[i-1,j]+1, dp[i,j-1]+1, dp[i-1,j-1]+cost)
    return dp[R,H] / max(1,R)

def load_ocr_gt(path):
    """
    Expect JSON list:
      [{"img":"path/to/crop.jpg","text":"12가3456"}, ...]
    """
    return json.loads(Path(path).read_text())

def load_charset(charlist_path):
    """
    charset.txt: one symbol per line, index = line number.
    Include [blank] token if your model uses CTC with blank; otherwise this function will add it as first token.
    """
    if charlist_path is None:
        # Minimal default: digits + uppercase Latin + few Hangul subset (example).
        base = list("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ가나다라마바사아자차카타파하")
        return ["[blank]"] + base
    symbols = [ln.strip("\n") for ln in Path(charlist_path).read_text(encoding="utf-8").splitlines() if ln.strip()!=""]
    # Ensure blank at index 0 for CTC; adjust if your model differs.
    if symbols[0] != "[blank]":
        symbols = ["[blank]"] + symbols
    return symbols

def preprocess_image(path, input_h, input_w, to_rgb=True, normalize=True):
    import cv2, numpy as np
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    if to_rgb:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (input_w, input_h), interpolation=cv2.INTER_LINEAR)
    if normalize:
        img = img.astype("float32") / 255.0
    # (H,W,3)->(1,H,W,3)
    return img[None, ...].astype("float32")

def greedy_ctc_decode(logits, charset):
    """
    Greedy decode for CTC-style outputs.
    logits: (T, C) or (1, T, C) or (C, T) or (1, C, T)
    Returns text string.
    """
    import numpy as np
    arr = np.array(logits)
    # Squeeze batch
    arr = np.squeeze(arr)
    # Ensure (T, C)
    if arr.ndim != 2:
        raise ValueError(f"Unexpected logits shape: {arr.shape}")
    T, C = arr.shape
    # Softmax along C for numerical stability (optional for argmax)
    probs = arr - arr.max(axis=1, keepdims=True)
    probs = np.exp(probs)
    probs = probs / (probs.sum(axis=1, keepdims=True) + 1e-9)
    ids = np.argmax(probs, axis=1).tolist()

    # Collapse repeats and remove blank (assume blank id=0)
    text_ids = []
    prev = None
    for i in ids:
        if i != 0 and i != prev:
            text_ids.append(i)
        prev = i
    # Map to chars
    chars = []
    for i in text_ids:
        if 0 <= i < len(charset):
            chars.append(charset[i])
        else:
            chars.append("?")
    return "".join(chars)

def infer_ocr_batch(model_kind, model_path, img_paths, input_hw, to_rgb=True, normalize=True, charset=None):
    """
    model_kind: "onnx" or "tflite"
    img_paths: list[str]
    input_hw: (H, W)
    charset: list[str] for CTC greedy decode
    Returns: list[str] predictions
    """
    H, W = input_hw
    if model_kind == "onnx":
        try:
            import onnxruntime as ort
        except Exception as e:
            raise RuntimeError("onnxruntime not installed. pip install onnxruntime") from e
        sess = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
        in_name = sess.get_inputs()[0].name
        out_name = sess.get_outputs()[0].name
        preds = []
        for p in img_paths:
            x = preprocess_image(p, H, W, to_rgb=to_rgb, normalize=normalize)  # (1,H,W,3)
            # Many OCR models expect NCHW; convert if needed by transposing.
            # Try NHWC first; if it fails, fallback to NCHW.
            try:
                y = sess.run([out_name], {in_name: x})[0]
            except Exception:
                x_nchw = np.transpose(x, (0,3,1,2)).astype("float32")
                y = sess.run([out_name], {in_name: x_nchw})[0]
            # Ensure (T,C) for decoding
            logit = np.squeeze(y)
            if logit.ndim == 3:  # (N,T,C) or (C,T,N)
                if logit.shape[0] == 1:
                    logit = logit[0]
                elif logit.shape[2] == 1:
                    logit = np.transpose(logit, (2,0,1))[0]
            if logit.shape[0] < logit.shape[1]:  # (C,T) -> (T,C)
                logit = np.transpose(logit, (1,0))
            preds.append(greedy_ctc_decode(logit, charset or ["[blank]"]))
        return preds

    elif model_kind == "tflite":
        # Try tflite_runtime first (lightweight), fallback to tensorflow.lite
        try:
            from tflite_runtime.interpreter import Interpreter
        except Exception:
            from tensorflow.lite.python.interpreter import Interpreter  # type: ignore
        inter = Interpreter(model_path=str(model_path))
        inter.allocate_tensors()
        in_det = inter.get_input_details()[0]
        out_det = inter.get_output_details()[0]
        in_idx = in_det["index"]
        out_idx = out_det["index"]
        preds = []
        for p in img_paths:
            x = preprocess_image(p, H, W, to_rgb=to_rgb, normalize=normalize)  # (1,H,W,3) float32
            # If model expects uint8/int8, convert
            if in_det["dtype"].__name__ in ("uint8","int8"):
                x = (x * 255.0).astype(in_det["dtype"])
            # NHWC assumed; if your model is NCHW, export should be adjusted.
            inter.set_tensor(in_idx, x)
            inter.invoke()
            y = inter.get_tensor(out_idx)  # expect (1,T,C) or (1,C,T) etc.
            logit = np.squeeze(y)
            if logit.ndim == 3:
                if logit.shape[0] == 1:
                    logit = logit[0]
                elif logit.shape[2] == 1:
                    logit = np.transpose(logit, (2,0,1))[0]
            if logit.shape[0] < logit.shape[1]:
                logit = np.transpose(logit, (1,0))
            preds.append(greedy_ctc_decode(logit, charset or ["[blank]"]))
        return preds

    else:
        raise ValueError(f"Unsupported model_kind: {model_kind}")

def eval_ocr(model_kind, model_path, gt_json, input_hw=(48,160), to_rgb=True, normalize=True, charset=None):
    data = load_ocr_gt(gt_json)
    imgs = [d["img"] for d in data]
    refs = [d["text"] for d in data]
    preds = infer_ocr_batch(model_kind, model_path, imgs, input_hw, to_rgb=to_rgb, normalize=normalize, charset=charset)
    cers = [cer(r, p) for r, p in zip(refs, preds)]
    return {"count": len(imgs), "CER_mean": float(np.mean(cers)), "CER_median": float(np.median(cers))}

def eval_det_coco(pred_json_path, gt_json_path):
    # Stub: integrate pycocotools to compute mAP if you export predictions to COCO format.
    # from pycocotools.coco import COCO
    # from pycocotools.cocoeval import COCOeval
    return {"mAP": None}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ocr-gt", type=Path, help="OCR eval GT JSON")
    ap.add_argument("--ocr-model", type=Path, help="Model path (.onnx or .tflite)")
    ap.add_argument("--ocr-kind", choices=["onnx","tflite"], default="onnx")
    ap.add_argument("--charlist", type=Path, help="Path to charset.txt (one symbol per line). Include [blank] as first line for CTC if applicable.")
    ap.add_argument("--input-size", type=str, default="48,160", help="H,W (e.g., 48,160)")
    ap.add_argument("--bgr", action="store_true", help="If set, do NOT convert BGR->RGB (e.g., when your training used BGR).")
    ap.add_argument("--no-norm", action="store_true", help="If set, skip /255 normalization (for uint8 pipelines).")

    args = ap.parse_args()

    if args.ocr_gt and args.ocr_model:
        H, W = map(int, args.input_size.split(","))
        charset = load_charset(str(args.charlist) if args.charlist else None)
        res = eval_ocr(
            args.ocr_kind, args.ocr_model, args.ocr_gt,
            input_hw=(H,W),
            to_rgb=not args.bgr,
            normalize=not args.no_norm,
            charset=charset
        )
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        print("Provide --ocr-gt, --ocr-model to run OCR regression.")
